(* Exercice 1*)
(* syracuse : int -> int list *)
(* Calcule La suite de Syracuse d'un nombre entier *)
(* n : int , l'entier dont on calcule la suite *)
(* résultat : la suite de Syracuse de n*)
(* précondition : n>0 *)
(* Erreur : boucle infinie si ala conjecture de Syracuse est fausse *)

let syracuse n = assert false

let%test _ = syracuse 1 = [1]
let%test _ = syracuse 2 = [2; 1]
let%test _ = syracuse 3 = [3; 10; 5; 16; 8; 4; 2; 1]
let%test _ = syracuse 4 = [4; 2; 1]
let%test _ = syracuse 5 = [5; 16; 8; 4; 2; 1]
let%test _ = syracuse 6 = [6; 3; 10; 5; 16; 8; 4; 2; 1]
let%test _ = syracuse 10 = [10; 5; 16; 8; 4; 2; 1]
let%test _ = syracuse 13 = [13; 40; 20; 10; 5; 16; 8; 4; 2; 1]
let%test _ = syracuse 14 = [14; 7; 22; 11; 34; 17; 52; 26; 13; 40; 20; 10; 5; 16; 8; 4; 2; 1]
let%test _ = syracuse 15 = [15; 46; 23; 70; 35; 106; 53; 160; 80; 40; 20; 10; 5; 16; 8; 4; 2; 1]
let%test _ = syracuse 16 = [16; 8; 4; 2; 1]
let%test _ = syracuse 30 = [30; 15; 46; 23; 70; 35; 106; 53; 160; 80; 40; 20; 10; 5; 16; 8; 4; 2; 1]

(* tempsVolsAltitude : int -> int *)
(* Calcule le temps de vol en altitude de la suite de Syracuse d'un entier*)
(* n : int , l'entier dont on calcule le temps de vol en altitude de la suite de Syracuse *)
(* résultat : le temps de vol en altitude de la suite de Syracuse de n*)
(* précondition : n>0 *)
(* Erreur : boucle infinie si ala conjecture de Syracuse est fausse *)

let tempsVolsAltitude n = assert false

let%test _ = tempsVolsAltitude 1 = 0
let%test _ = tempsVolsAltitude 2 = 0
let%test _ = tempsVolsAltitude 3 = 5
let%test _ = tempsVolsAltitude 4 = 0
let%test _ = tempsVolsAltitude 5 = 2
let%test _ = tempsVolsAltitude 10 = 0
let%test _ = tempsVolsAltitude 13 = 2
let%test _ = tempsVolsAltitude 14 = 0
let%test _ = tempsVolsAltitude 15 = 10
let%test _ = tempsVolsAltitude 127 = 23



(* altitudeMax : int -> int *)
(* Calcule l'altitude maximale de la suite de Syracuse d'un entier*)
(* n : int , l'entier dont on calcule l'altitude maximale de la suite de Syracuse *)
(* résultat : l'altitude maximale de la suite de Syracuse de n*)
(* précondition : n>0 *)
(* Erreur : boucle infinie si ala conjecture de Syracuse est fausse *)


let altitudeMax n = assert false

let%test _ = altitudeMax 1 = 1
let%test _ = altitudeMax 2 = 2
let%test _ = altitudeMax 3 = 16
let%test _ = altitudeMax 4 = 4
let%test _ = altitudeMax 5 = 16
let%test _ = altitudeMax 10 = 16
let%test _ = altitudeMax 13 = 40
let%test _ = altitudeMax 14 = 52
let%test _ = altitudeMax 15 = 160
let%test _ = altitudeMax 127 = 4372 

(* Exercice 2 *)

(* Définition du type couleur pour étiqueter les noeuds en noir ou rouge *)
type couleur = Noir | Rouge
(* Définition du type des arbres bicolores *)
type 'a arbreBicolore = NIL | Noeud of 'a arbreBicolore * (couleur * 'a) * 'a arbreBicolore

let s6 = Noeud (NIL,(Rouge,6),NIL)
let s1 = Noeud (NIL,(Noir,1),s6)
let s11 = Noeud (NIL,(Noir,11),NIL)
let s8 = Noeud (s1,(Rouge,8),s11)
let s22 = Noeud (NIL,(Rouge,22),NIL)
let s27 = Noeud (NIL,(Rouge,27),NIL)
let s25 = Noeud (s22,(Noir,25),s27)
let s15 = Noeud (NIL,(Noir,15),NIL)
let s17 = Noeud (s15,(Rouge,17),s25)
let arbreSujet =  Noeud (s8,(Noir,13),s17)

let s25F = Noeud (s22,(Rouge,25),s27)
let s17F = Noeud (s15,(Rouge,17),s25F)
let arbreSujetF =  Noeud (s8,(Noir,13),s17F)


(* TO DO*)
let estABR a = assert false

(* TO DO tests unitaires de estABR *)


(* filsRougeNoirs : 'a arbreBicolore -> bool *)
(* Vérifie que les enfants d'un noeud rouge sont noirs *)
(* a : 'a arbreBicolore, l'arbre à vérifier *)
(* résultat : un booléen indiquant si a valide la propriété *)

let filsRougeNoirs a = assert false

let%test _ = filsRougeNoirs s6
let%test _ = filsRougeNoirs s1
let%test _ = filsRougeNoirs s11
let%test _ = filsRougeNoirs s8
let%test _ = filsRougeNoirs s22
let%test _ = filsRougeNoirs s27
let%test _ = filsRougeNoirs s25
let%test _ = filsRougeNoirs s15
let%test _ = filsRougeNoirs s17
let%test _ = filsRougeNoirs arbreSujet
let%test _ = not (filsRougeNoirs s25F)
let%test _ = not (filsRougeNoirs arbreSujetF)

exception HauteurNoireException


(* hauteurNoire : 'a arbreBicolore -> int *)
(* Renvoie la hauteur noire d'un arbre *)
(* a : 'a arbreBicolore, l'arbre dont on veut calculer la hauteur noire *)
(* résultat : la hauteur noire de a *)
(* Excception : l'exception HauteurNoireException est levée si tous les chemins de la racine *)
(* à n'importe quelle feuille (NIL) ne contiennent pas le même nombre de nœuds noirs *)


let hauteurNoire a = assert false

  let%test _ = hauteurNoire s6 = 1
  let%test _ = hauteurNoire s1 = 2
  let%test _ = hauteurNoire s11 = 2
  let%test _ = hauteurNoire s8 = 2
  let%test _ = hauteurNoire s22 = 1
  let%test _ = hauteurNoire s27 = 1
  let%test _ = hauteurNoire s25 = 2
  let%test _ = hauteurNoire s15 = 2
  let%test _ = hauteurNoire s17 = 2
  let%test _ = hauteurNoire arbreSujet = 3
  let%test _ = 
    try
      let _ = hauteurNoire (Noeud (s6,(Noir,13),s17)) in false
    with HauteurNoireException -> true
  let%test _ = 
    try
      let _ = hauteurNoire (Noeud (s8,(Noir,13),s22)) in false
    with HauteurNoireException -> true
  let%test _ = 
    try
      let _ = hauteurNoire (Noeud (NIL,(Noir,13),s17)) in false
    with HauteurNoireException -> true
  let%test _ = 
    try
      let _ = hauteurNoire (Noeud (s8,(Noir,13),NIL)) in false
    with HauteurNoireException -> true


(* estArbreBicolore : 'a arbreBicolore -> bool *)
(* Vérifie qu'un arbre valide les propriétés d'un arbre bicolore *)
(* a : 'a arbreBicolore, l'arbre à vérifier *)
(* résultat : un booléen indiquant si a est un arbre bicolore *)

let estArbreBicolore a = assert false

let%test _ = estArbreBicolore s1
let%test _ = estArbreBicolore s11
let%test _ = estArbreBicolore s25
let%test _ = estArbreBicolore s15
let%test _ = estArbreBicolore arbreSujet
let%test _ = not (estArbreBicolore (Noeud (s22,(Noir,11),s27)))
let%test _ = not (estArbreBicolore (Noeud (s27,(Noir,25),s22)))
let%test _ = not (estArbreBicolore (Noeud (NIL,(Noir,10),s6)))
let%test _ = not (estArbreBicolore (Noeud (s6,(Noir,1),NIL)))
let%test _ = not (estArbreBicolore s25F)
let%test _ = not (estArbreBicolore arbreSujetF)
let%test _ = not (estArbreBicolore (Noeud (s6,(Noir,13),s17)))
let%test _ = not (estArbreBicolore (Noeud (s8,(Noir,13),s22)))
let%test _ = not (estArbreBicolore (Noeud (NIL,(Noir,13),s17)))
let%test _ = not (estArbreBicolore (Noeud (s8,(Noir,13),NIL)))
let%test _ = not (estArbreBicolore s8)
let%test _ = not (estArbreBicolore s6)
let%test _ = not (estArbreBicolore s17)
let%test _ = not (estArbreBicolore s22)
let%test _ = not (estArbreBicolore s27)