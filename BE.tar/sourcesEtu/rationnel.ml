(****************************)
(** Expressions régulières **)
(****************************)

(* Type des expressions régulières sur l'alphabet 'a *)
type 'a expReg =
  | Symbole of 'a (* Symbole de l'alphabet *)
  | Lambda (* Mot vide *)
  | Vide (* Ensemble vide *)
  | Ou of 'a expReg * 'a expReg (* exp + exp *)
  | Suite of 'a expReg * 'a expReg (* exp.exp *)
  | Etoile of 'a expReg
(*exp * *)

(* Définition des expressions régulières du sujet pour les tests*)
(* (a+b)*  *)
let expReg1 = Etoile (Ou (Symbole 'a', Symbole 'b'))

(* a.(b+c).a* *)
let expReg2 =
  Suite
    (Suite (Symbole 'a', Ou (Symbole 'b', Symbole 'c')), Etoile (Symbole 'a'))

let expReg2Bis =
  Suite
    (Symbole 'a', Suite (Ou (Symbole 'b', Symbole 'c'), Etoile (Symbole 'a')))

let expReg3 = Ou (Etoile (Symbole 1), Etoile (Symbole 0))

(* CONTRAT : TO DO *)
let rec mot_vide_dans  = fun _ -> assert false

(* TESTS : TO DO *)

(* derive : 'a -> 'a expReg -> 'a expReg *)
(* Calcule la dérivée par rapport à a de l'exp e *)
(* a : le symbole du langage par rapport auquel est dérivée l'expression *)
(* e : l'expression à dériver *)
(* La simplification de l'expression obtenue n'est pas demandée *)
let rec derive = fun _ -> assert false

(* Les tests ne passeront que si AUCUNE simplification de l'expression obtenue n'est faite *)
(* Si vous faites des simplifications, écrivez vos propres tests *)
(*
let%test _ = derive 'a' Lambda = Vide
let%test _ = derive 'a' Vide = Vide
let%test _ = derive 'a' (Symbole 'b') = Vide
let%test _ = derive 'a' (Symbole 'a') = Lambda
let%test _ = derive 'a' (Ou (Symbole 'a', Symbole 'b')) = Ou (Lambda, Vide)

let%test _ =
  derive 'a' (Suite (Symbole 'a', Symbole 'b'))
  = Ou (Suite (Lambda, Symbole 'b'), Suite (Vide, Vide))

let%test _ =
  derive 'a' (Suite (Symbole 'b', Symbole 'a'))
  = Ou (Suite (Vide, Symbole 'a'), Suite (Vide, Lambda))

let%test _ =
  derive 'a' (Etoile (Symbole 'a')) = Suite (Lambda, Etoile (Symbole 'a'))

let%test _ =
  derive 'a' (Etoile (Symbole 'b')) = Suite (Vide, Etoile (Symbole 'b'))

let%test _ = derive 'a' expReg1 = Suite (Ou (Lambda, Vide), expReg1)
let%test _ = derive 'b' expReg1 = Suite (Ou (Vide, Lambda), expReg1)

let%test _ =
  derive 'a' (Suite (Symbole 'a', Ou (Symbole 'b', Symbole 'c')))
  = Ou
      ( Suite (Lambda, Ou (Symbole 'b', Symbole 'c')),
        Suite (Vide, Ou (Vide, Vide)) )

let%test _ =
  derive 'a' expReg2
  = Ou
      ( Suite
          ( Ou
              ( Suite (Lambda, Ou (Symbole 'b', Symbole 'c')),
                Suite (Vide, Ou (Vide, Vide)) ),
            Etoile (Symbole 'a') ),
        Suite (Vide, Suite (Lambda, Etoile (Symbole 'a'))) )

let%test _ =
  derive 1 expReg3
  = Ou (Suite (Lambda, Etoile (Symbole 1)), Suite (Vide, Etoile (Symbole 0)))

let%test _ =
  derive 0 expReg3
  = Ou (Suite (Vide, Etoile (Symbole 1)), Suite (Lambda, Etoile (Symbole 0)))
  *)

(* appartient_langage_expReg : 'a expReg -> 'a list -> bool *)
(* Teste si un mot appartient au langage associé à l'expression régulière *)
let rec appartient_langage_expReg  = fun _ -> assert false

(*
let%test _ = appartient_langage_expReg expReg1 []
let%test _ = appartient_langage_expReg expReg1 [ 'a' ]
let%test _ = appartient_langage_expReg expReg1 [ 'b' ]
let%test _ = appartient_langage_expReg expReg1 [ 'a'; 'a' ]
let%test _ = appartient_langage_expReg expReg1 [ 'a'; 'b' ]
let%test _ = appartient_langage_expReg expReg1 [ 'b'; 'a'; 'b'; 'b' ]
let%test _ = not (appartient_langage_expReg expReg1 [ 'c' ])
let%test _ = not (appartient_langage_expReg expReg1 [ 'c'; 'a'; 'b' ])
let%test _ = not (appartient_langage_expReg expReg1 [ 'a'; 'a'; 'c' ])
let%test _ = not (appartient_langage_expReg expReg1 [ 'a'; 'c'; 'b' ])
let%test _ = not (appartient_langage_expReg expReg1 [ 'c' ])
let%test _ = not (appartient_langage_expReg expReg1 [ 'c'; 'a'; 'b' ])
let%test _ = not (appartient_langage_expReg expReg1 [ 'a'; 'a'; 'c' ])
let%test _ = not (appartient_langage_expReg expReg1 [ 'a'; 'c'; 'b' ])
let%test _ = not (appartient_langage_expReg expReg1 [ 'd' ])
let%test _ = appartient_langage_expReg expReg2 [ 'a'; 'b' ]
let%test _ = appartient_langage_expReg expReg2 [ 'a'; 'c' ]
let%test _ = appartient_langage_expReg expReg2 [ 'a'; 'b'; 'a' ]
let%test _ = appartient_langage_expReg expReg2 [ 'a'; 'c'; 'a'; 'a' ]
let%test _ = appartient_langage_expReg expReg2 [ 'a'; 'b'; 'a'; 'a'; 'a' ]
let%test _ = appartient_langage_expReg expReg2 [ 'a'; 'c'; 'a'; 'a'; 'a'; 'a' ]
let%test _ = appartient_langage_expReg expReg2Bis [ 'a'; 'b' ]
let%test _ = appartient_langage_expReg expReg2Bis [ 'a'; 'c' ]
let%test _ = appartient_langage_expReg expReg2Bis [ 'a'; 'b'; 'a' ]
let%test _ = appartient_langage_expReg expReg2Bis [ 'a'; 'c'; 'a'; 'a' ]
let%test _ = appartient_langage_expReg expReg2Bis [ 'a'; 'b'; 'a'; 'a'; 'a' ]

let%test _ =
  appartient_langage_expReg expReg2Bis [ 'a'; 'c'; 'a'; 'a'; 'a'; 'a' ]

let%test _ = not (appartient_langage_expReg expReg2 [ 'a'; 'b'; 'b' ])
let%test _ = not (appartient_langage_expReg expReg2 [ 'a'; 'b'; 'c' ])
let%test _ = not (appartient_langage_expReg expReg2 [ 'a'; 'c'; 'b' ])
let%test _ = not (appartient_langage_expReg expReg2 [ 'a'; 'c'; 'c' ])
let%test _ = not (appartient_langage_expReg expReg2 [ 'c'; 'b' ])
let%test _ = not (appartient_langage_expReg expReg2 [ 'c'; 'c' ])
let%test _ = not (appartient_langage_expReg expReg2 [ 'c'; 'b'; 'a' ])
let%test _ = not (appartient_langage_expReg expReg2 [ 'c'; 'c'; 'a'; 'a' ])
let%test _ = not (appartient_langage_expReg expReg2 [ 'c'; 'b'; 'a'; 'a'; 'a' ])

let%test _ =
  not (appartient_langage_expReg expReg2 [ 'c'; 'c'; 'a'; 'a'; 'a'; 'a' ])

let%test _ = not (appartient_langage_expReg expReg2 [ 'b'; 'b' ])
let%test _ = not (appartient_langage_expReg expReg2 [ 'b'; 'c' ])
let%test _ = not (appartient_langage_expReg expReg2 [ 'b'; 'b'; 'a' ])
let%test _ = not (appartient_langage_expReg expReg2 [ 'b'; 'c'; 'a'; 'a' ])
let%test _ = not (appartient_langage_expReg expReg2 [ 'b'; 'b'; 'a'; 'a'; 'a' ])
let%test _ = not (appartient_langage_expReg expReg2 [ 'd' ])

let%test _ =
  not (appartient_langage_expReg expReg2 [ 'b'; 'c'; 'a'; 'a'; 'a'; 'a' ])

let%test _ = not (appartient_langage_expReg expReg2Bis [ 'a'; 'b'; 'b' ])
let%test _ = not (appartient_langage_expReg expReg2Bis [ 'a'; 'b'; 'c' ])
let%test _ = not (appartient_langage_expReg expReg2Bis [ 'a'; 'c'; 'b' ])
let%test _ = not (appartient_langage_expReg expReg2Bis [ 'a'; 'c'; 'c' ])
let%test _ = not (appartient_langage_expReg expReg2Bis [ 'c'; 'b' ])
let%test _ = not (appartient_langage_expReg expReg2Bis [ 'c'; 'c' ])
let%test _ = not (appartient_langage_expReg expReg2Bis [ 'c'; 'b'; 'a' ])
let%test _ = not (appartient_langage_expReg expReg2Bis [ 'c'; 'c'; 'a'; 'a' ])

let%test _ =
  not (appartient_langage_expReg expReg2Bis [ 'c'; 'b'; 'a'; 'a'; 'a' ])

let%test _ =
  not (appartient_langage_expReg expReg2Bis [ 'c'; 'c'; 'a'; 'a'; 'a'; 'a' ])

let%test _ = not (appartient_langage_expReg expReg2Bis [ 'b'; 'b' ])
let%test _ = not (appartient_langage_expReg expReg2Bis [ 'b'; 'c' ])
let%test _ = not (appartient_langage_expReg expReg2Bis [ 'b'; 'b'; 'a' ])
let%test _ = not (appartient_langage_expReg expReg2Bis [ 'b'; 'c'; 'a'; 'a' ])

let%test _ =
  not (appartient_langage_expReg expReg2Bis [ 'b'; 'b'; 'a'; 'a'; 'a' ])

let%test _ =
  not (appartient_langage_expReg expReg2Bis [ 'b'; 'c'; 'a'; 'a'; 'a'; 'a' ])

let%test _ = not (appartient_langage_expReg expReg2Bis [ 'd' ])
let%test _ = appartient_langage_expReg expReg3 []
let%test _ = appartient_langage_expReg expReg3 [ 1 ]
let%test _ = appartient_langage_expReg expReg3 [ 1; 1 ]
let%test _ = appartient_langage_expReg expReg3 [ 1; 1; 1 ]
let%test _ = appartient_langage_expReg expReg3 [ 1; 1; 1; 1 ]
let%test _ = appartient_langage_expReg expReg3 [ 0 ]
let%test _ = appartient_langage_expReg expReg3 [ 0; 0 ]
let%test _ = appartient_langage_expReg expReg3 [ 0; 0; 0 ]
let%test _ = appartient_langage_expReg expReg3 [ 0; 0; 0; 0 ]
let%test _ = not (appartient_langage_expReg expReg3 [ 1; 0 ])
let%test _ = not (appartient_langage_expReg expReg3 [ 2 ])
let%test _ = not (appartient_langage_expReg expReg3 [ 0; 1 ])
let%test _ = not (appartient_langage_expReg expReg3 [ 1; 0; 1 ])
let%test _ = not (appartient_langage_expReg expReg3 [ 1; 0; 0 ])
let%test _ = not (appartient_langage_expReg expReg3 [ 0; 1; 1 ])
let%test _ = not (appartient_langage_expReg expReg3 [ 0; 1; 0 ])
*)

(*********************************)
(** Automates déterministes **)
(*********************************)

(* Un automate fini non déterministe est un quintuplet *)
type ('a, 'b) afd =
  | AFD of
      'b list
      (* ensemble fini d'états *)
      * 'a list
      (* alphabet *)
      * ('b * 'a * 'b) list
      (* transitions de l'automate *)
      * 'b
      (* état initial de l'automate*)
      * 'b list
(* états finaux de l'automate *)

(** Automates du sujet pour des tests **)
let afd1 =
  AFD
    ([ 0; 1 ], [ 'a'; 'b' ], [ (0, 'a', 1); (1, 'a', 0); (1, 'b', 1) ], 0, [ 1 ])

let afd2 =
  AFD
    ( [ "q0"; "q1"; "q2" ],
      [ 0; 1 ],
      [ ("q0", 1, "q1"); ("q1", 0, "q1"); ("q1", 1, "q2") ],
      "q0",
      [ "q1"; "q2" ] )

let afd3 =
  AFD
    ( [ "q0"; "q1"; "q2"; "q3"; "q4"; "q5"; "q6"; "q7" ],
      [ 'a'; 'b'; 'c' ],
      [
        ("q0", 'a', "q1");
        ("q0", 'b', "q3");
        ("q1", 'c', "q2");
        ("q1", 'b', "q4");
        ("q2", 'c', "q1");
        ("q2", 'b', "q5");
        ("q3", 'a', "q4");
        ("q3", 'b', "q6");
        ("q4", 'b', "q5");
        ("q4", 'c', "q6");
        ("q5", 'a', "q7");
        ("q5", 'b', "q5");
        ("q6", 'a', "q6");
        ("q6", 'c', "q4");
        ("q7", 'a', "q6");
        ("q7", 'b', "q4");
      ],
      "q0",
      [ "q0"; "q2"; "q6"; "q7" ] )

(* Pour les tests *)
(* [eq_perm l l'] retourne true ssi [l] et [l']
   sont égales à à permutation près (pour (=)).
   [l'] ne doit pas contenir de doublon. *)
let eq_perm l l' =
  List.length l = List.length l' && List.for_all (fun x -> List.mem x l) l'

(* init_finaux_bienformees : ('a, 'b) afd -> bool *)
(* Vérifie qui les états initiaux et les états terminaux *)
(* sont bien déclarés comme états de l'automates. *)
let init_finaux_bienformees  = fun _ -> assert false

(*
let%test _ = init_finaux_bienformees afd1
let%test _ = init_finaux_bienformees afd2
let%test _ = init_finaux_bienformees afd3

let%test _ =
  not
    (init_finaux_bienformees
       (AFD
          ( [ 0; 1 ],
            [ 'a'; 'b' ],
            [ (0, 'a', 1); (1, 'a', 0); (1, 'b', 1) ],
            3,
            [ 1 ] )))

let%test _ =
  not
    (init_finaux_bienformees
       (AFD
          ( [ 0; 1 ],
            [ 'a'; 'b' ],
            [ (0, 'a', 1); (1, 'a', 0); (1, 'b', 1) ],
            0,
            [ 3 ] )))

let%test _ =
  not
    (init_finaux_bienformees
       (AFD
          ( [ 0; 1 ],
            [ 'a'; 'b' ],
            [ (0, 'a', 1); (1, 'a', 0); (1, 'b', 1) ],
            0,
            [ 1; 3; 0 ] )))
*)

(* transitions_bienformees :  ('a, 'b) afd -> bool *)
(* Vérifie que les transitions sont bien formée, c'est à dire que *)
(* les états de départ et d'arrivée des transitions sont bien déclarés *)
(* comme états de l'automates et que les symboles des transitions sont *)
(* bien dans l'alphabet de l'automates *)
let transitions_bienformees  = fun _ -> assert false

(*
let%test _ = transitions_bienformees afd1
let%test _ = transitions_bienformees afd2
let%test _ = transitions_bienformees afd3

let%test _ =
  not
    (transitions_bienformees
       (AFD
          ( [ 0; 1 ],
            [ 'a'; 'b' ],
            [ (3, 'a', 1); (1, 'a', 0); (1, 'b', 1) ],
            0,
            [ 1 ] )))

let%test _ =
  not
    (transitions_bienformees
       (AFD
          ( [ 0; 1 ],
            [ 'a'; 'b' ],
            [ (0, 'a', 3); (1, 'a', 0); (1, 'b', 1) ],
            0,
            [ 1 ] )))

let%test _ =
  not
    (transitions_bienformees
       (AFD
          ( [ 0; 1 ],
            [ 'a'; 'b' ],
            [ (0, 'a', 1); (1, 'a', 3); (1, 'b', 1) ],
            0,
            [ 1 ] )))

let%test _ =
  not
    (transitions_bienformees
       (AFD
          ( [ 0; 1 ],
            [ 'a'; 'b' ],
            [ (0, 'a', 1); (3, 'a', 0); (1, 'b', 1) ],
            0,
            [ 1 ] )))

let%test _ =
  not
    (transitions_bienformees
       (AFD
          ( [ 0; 1 ],
            [ 'a'; 'b' ],
            [ (0, 'c', 1); (1, 'a', 0); (1, 'b', 1) ],
            0,
            [ 1 ] )))

let%test _ =
  not
    (transitions_bienformees
       (AFD
          ( [ 0; 1 ],
            [ 'a'; 'b' ],
            [ (0, 'a', 1); (1, 'c', 0); (1, 'b', 1) ],
            0,
            [ 1 ] )))
*)

(* get_destinations : ('a,'b) afnd -> 'b -> 'a -> 'b list *)
(* Calcule la liste de états étteignable depuis [etat] par la transition [trans] *)
let get_destinations = fun _ -> assert false

(*
let%test _ = eq_perm (get_destinations afd1 0 'a') [ 1 ]
let%test _ = eq_perm (get_destinations afd1 0 'b') []
let%test _ = eq_perm (get_destinations afd1 1 'a') [ 0 ]
let%test _ = eq_perm (get_destinations afd1 1 'b') [ 1 ]
let%test _ = eq_perm (get_destinations afd2 "q0" 0) []
let%test _ = eq_perm (get_destinations afd2 "q0" 1) [ "q1" ]
let%test _ = eq_perm (get_destinations afd2 "q1" 0) [ "q1" ]
let%test _ = eq_perm (get_destinations afd2 "q1" 1) [ "q2" ]
let%test _ = eq_perm (get_destinations afd2 "q2" 0) []
let%test _ = eq_perm (get_destinations afd2 "q2" 1) []
let%test _ = eq_perm (get_destinations afd3 "q0" 'a') [ "q1" ]
let%test _ = eq_perm (get_destinations afd3 "q0" 'b') [ "q3" ]
let%test _ = eq_perm (get_destinations afd3 "q0" 'c') []
let%test _ = eq_perm (get_destinations afd3 "q1" 'a') []
let%test _ = eq_perm (get_destinations afd3 "q1" 'b') [ "q4" ]
let%test _ = eq_perm (get_destinations afd3 "q1" 'c') [ "q2" ]
let%test _ = eq_perm (get_destinations afd3 "q2" 'a') []
let%test _ = eq_perm (get_destinations afd3 "q2" 'b') [ "q5" ]
let%test _ = eq_perm (get_destinations afd3 "q2" 'c') [ "q1" ]
let%test _ = eq_perm (get_destinations afd3 "q3" 'a') [ "q4" ]
let%test _ = eq_perm (get_destinations afd3 "q3" 'b') [ "q6" ]
let%test _ = eq_perm (get_destinations afd3 "q3" 'c') []
let%test _ = eq_perm (get_destinations afd3 "q4" 'a') []
let%test _ = eq_perm (get_destinations afd3 "q4" 'b') [ "q5" ]
let%test _ = eq_perm (get_destinations afd3 "q4" 'c') [ "q6" ]
let%test _ = eq_perm (get_destinations afd3 "q5" 'a') [ "q7" ]
let%test _ = eq_perm (get_destinations afd3 "q5" 'b') [ "q5" ]
let%test _ = eq_perm (get_destinations afd3 "q5" 'c') []
let%test _ = eq_perm (get_destinations afd3 "q6" 'a') [ "q6" ]
let%test _ = eq_perm (get_destinations afd3 "q6" 'b') []
let%test _ = eq_perm (get_destinations afd3 "q6" 'c') [ "q4" ]
let%test _ = eq_perm (get_destinations afd3 "q7" 'a') [ "q6" ]
let%test _ = eq_perm (get_destinations afd3 "q7" 'b') [ "q4" ]
let%test _ = eq_perm (get_destinations afd3 "q7" 'c') []

let%test _ = eq_perm (get_destinations 
(AFD
   ( [ 0; 1 ],
     [ 'a'; 'b' ],
     [ (0, 'a', 1); (0, 'a', 0); (1, 'b', 1) ],
     0,
     [ 1 ] )) 0 'a') [1;0]

let%test _ = eq_perm (get_destinations
(AFD
( [ "q0"; "q1"; "q2" ],
  [ 0; 1 ],
  [ ("q0", 1, "q0"); ("q0", 1, "q1"); ("q0", 1, "q2") ],
  "q0",
  [ "q1"; "q2" ] ))
"q0"
1
) ["q0"; "q1"; "q2"]
*)


(* destination_par_etat_transition : ('a,'b) afnd -> (('b * 'a transition)*'b list) list *)
(* pour l'automate [a], renvoies une liste associative où les clées sont les couples (état, transition) *)
(* et les valeurs, la liste des états ateignables depuis l'état par la transitions *)
(* Tous les couples (état, transition) doivent être présent dans la liste *)
let destinations_par_etat_transition = fun _ -> assert false

(*
let%test _ =
  eq_perm
    (destinations_par_etat_transition afd1)
    [ ((0, 'a'), [ 1 ]); ((0, 'b'), []); ((1, 'a'), [ 0 ]); ((1, 'b'), [ 1 ]) ]

let%test _ =
  eq_perm
    (destinations_par_etat_transition afd2)
    [
      (("q0", 0), []);
      (("q0", 1), [ "q1" ]);
      (("q1", 0), [ "q1" ]);
      (("q1", 1), [ "q2" ]);
      (("q2", 0), []);
      (("q2", 1), []);
    ]

let%test _ =
  eq_perm
    (destinations_par_etat_transition afd3)
    [
      (("q0", 'a'), [ "q1" ]);
      (("q0", 'b'), [ "q3" ]);
      (("q0", 'c'), []);
      (("q1", 'a'), []);
      (("q1", 'b'), [ "q4" ]);
      (("q1", 'c'), [ "q2" ]);
      (("q2", 'a'), []);
      (("q2", 'b'), [ "q5" ]);
      (("q2", 'c'), [ "q1" ]);
      (("q3", 'a'), [ "q4" ]);
      (("q3", 'b'), [ "q6" ]);
      (("q3", 'c'), []);
      (("q4", 'a'), []);
      (("q4", 'b'), [ "q5" ]);
      (("q4", 'c'), [ "q6" ]);
      (("q5", 'a'), [ "q7" ]);
      (("q5", 'b'), [ "q5" ]);
      (("q5", 'c'), []);
      (("q6", 'a'), [ "q6" ]);
      (("q6", 'b'), []);
      (("q6", 'c'), [ "q4" ]);
      (("q7", 'a'), [ "q6" ]);
      (("q7", 'b'), [ "q4" ]);
      (("q7", 'c'), []);
    ]

let%test _ = eq_perm
(destinations_par_etat_transition (AFD
( [ 0; 1 ],
  [ 'a'; 'b' ],
  [ (0, 'a', 1); (0, 'a', 0); (1, 'b', 1) ],
  0,
  [ 1 ] )))
[((0, 'a'), [1; 0]); ((0, 'b'), []); ((1, 'a'), []); ((1, 'b'), [1])]
||
eq_perm
(destinations_par_etat_transition (AFD
( [ 0; 1 ],
  [ 'a'; 'b' ],
  [ (0, 'a', 1); (0, 'a', 0); (1, 'b', 1) ],
  0,
  [ 1 ] )))
[((0, 'a'), [0; 1]); ((0, 'b'), []); ((1, 'a'), []); ((1, 'b'), [1])]
*)
(* ('a,'b) afnd -> bool *)
(* Indique si l'automate est déterministe *)
let est_deterministe  = fun _ -> assert false

(*
let%test _ = est_deterministe afd1
let%test _ = est_deterministe afd2
let%test _ = est_deterministe afd3
let%test _ = not (est_deterministe (AFD
( [ 0; 1 ],
  [ 'a'; 'b' ],
  [ (0, 'a', 1); (0, 'a', 0); (1, 'b', 1) ],
  0,
  [ 1 ] )))
let%test _ = not (est_deterministe (AFD
( [ "q0"; "q1"; "q2" ],
  [ 0; 1 ],
  [ ("q0", 1, "q0"); ("q0", 1, "q1"); ("q0", 1, "q2") ],
  "q0",
  [ "q1"; "q2" ] )))
*)

(* appartient_langage_afd ('a,'b) afd -> 'a list -> bool *)
(* Vérifie si le mot [mot] appartient_langage_afd au langage associé à l'automate [a] *)
let appartient_langage_afd  = fun _ -> assert false

(*
let%test _ = appartient_langage_afd afd1 [ 'a' ]
let%test _ = appartient_langage_afd afd1 [ 'a'; 'b' ]
let%test _ = appartient_langage_afd afd1 [ 'a'; 'b'; 'b' ]
let%test _ = appartient_langage_afd afd1 [ 'a'; 'b'; 'b'; 'a'; 'a' ]

let%test _ =
  appartient_langage_afd afd1 [ 'a'; 'b'; 'b'; 'a'; 'a'; 'b'; 'b'; 'b' ]

let%test _ = appartient_langage_afd afd1 [ 'a'; 'b'; 'a'; 'a' ]
let%test _ = not (appartient_langage_afd afd1 [])
let%test _ = not (appartient_langage_afd afd1 [ 'b' ])
let%test _ = not (appartient_langage_afd afd1 [ 'c' ])
let%test _ = not (appartient_langage_afd afd1 [ 'a'; 'b'; 'a' ])
let%test _ = not (appartient_langage_afd afd1 [ 'a'; 'b'; 'a'; 'b' ])
let%test _ = appartient_langage_afd afd2 [ 1 ]
let%test _ = appartient_langage_afd afd2 [ 1; 1 ]
let%test _ = appartient_langage_afd afd2 [ 1; 0 ]
let%test _ = appartient_langage_afd afd2 [ 1; 0; 1 ]
let%test _ = appartient_langage_afd afd2 [ 1; 0; 0 ]
let%test _ = appartient_langage_afd afd2 [ 1; 0; 0; 1 ]
let%test _ = appartient_langage_afd afd2 [ 1; 0; 0; 0 ]
let%test _ = appartient_langage_afd afd2 [ 1; 0; 0; 0; 1 ]
let%test _ = appartient_langage_afd afd2 [ 1; 0; 0; 0; 0 ]
let%test _ = not (appartient_langage_afd afd2 [])
let%test _ = not (appartient_langage_afd afd2 [ 0 ])
let%test _ = not (appartient_langage_afd afd2 [ 1; 1; 1 ])
let%test _ = not (appartient_langage_afd afd2 [ 0; 1 ])
let%test _ = not (appartient_langage_afd afd2 [ 1; 0; 1; 1 ])
let%test _ = not (appartient_langage_afd afd2 [ 0; 0; 0 ])
let%test _ = appartient_langage_afd afd3 []
let%test _ = appartient_langage_afd afd3 [ 'a'; 'c' ]
let%test _ = appartient_langage_afd afd3 [ 'a'; 'c'; 'c'; 'c' ]
let%test _ = appartient_langage_afd afd3 [ 'a'; 'c'; 'b'; 'a' ]
let%test _ = appartient_langage_afd afd3 [ 'a'; 'c'; 'b'; 'a'; 'a' ]
let%test _ = appartient_langage_afd afd3 [ 'b'; 'b' ]
let%test _ = appartient_langage_afd afd3 [ 'b'; 'b'; 'a' ]
let%test _ = appartient_langage_afd afd3 [ 'b'; 'b'; 'a'; 'a' ]
let%test _ = appartient_langage_afd afd3 [ 'b'; 'b'; 'c'; 'c' ]
let%test _ = appartient_langage_afd afd3 [ 'b'; 'b'; 'c'; 'c'; 'a' ]
let%test _ = appartient_langage_afd afd3 [ 'b'; 'a'; 'c' ]
let%test _ = appartient_langage_afd afd3 [ 'a'; 'b'; 'c' ]
let%test _ = appartient_langage_afd afd3 [ 'a'; 'b'; 'b'; 'a' ]
let%test _ = not (appartient_langage_afd afd3 [ 'a' ])
let%test _ = not (appartient_langage_afd afd3 [ 'b' ])
let%test _ = not (appartient_langage_afd afd3 [ 'c' ])
let%test _ = not (appartient_langage_afd afd3 [ 'a'; 'b' ])
let%test _ = not (appartient_langage_afd afd3 [ 'b'; 'a' ])
let%test _ = not (appartient_langage_afd afd3 [ 'b'; 'a'; 'b' ])
let%test _ = not (appartient_langage_afd afd3 [ 'a'; 'b'; 'b' ])
let%test _ = not (appartient_langage_afd afd3 [ 'a'; 'b'; 'a' ])
let%test _ = not (appartient_langage_afd afd3 [ 'c'; 'a' ])
let%test _ = not (appartient_langage_afd afd3 [ 'c'; 'b' ])

let%test _ = 
try
  let _ = appartient_langage_afd (AFD
  ( [ 0; 1 ],
    [ 'a'; 'b' ],
    [ (0, 'a', 1); (0, 'a', 0); (1, 'b', 1) ],
    0,
    [ 1 ] )) ['a'] in false
with AutomateNonDeterministe -> true

let%test _ = 
try
  let _ = appartient_langage_afd (AFD
  ( [ 0; 1 ],
    [ 'a'; 'b' ],
    [ (0, 'a', 1); (1, 'b', 0); (1, 'b', 1) ],
    0,
    [ 1 ] )) ['a'] in false
with AutomateNonDeterministe -> true

let%test _ = 
try
  let _ = appartient_langage_afd (AFD
( [ "q0"; "q1"; "q2" ],
  [ 0; 1 ],
  [ ("q0", 1, "q0"); ("q0", 1, "q1"); ("q0", 1, "q2") ],
  "q0",
  [ "q1"; "q2" ] )) [1] in false
with AutomateNonDeterministe -> true
*)